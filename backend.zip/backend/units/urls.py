from django.urls import path

# Placeholder URL patterns for units app
# Add your specific endpoints here

urlpatterns = [
    # Add your URL patterns here
    # Example:
    # path('catalogue/', views.catalogue_list, name='catalogue_list'),
    # path('semesters/', views.semesters_list, name='semesters_list'),
]