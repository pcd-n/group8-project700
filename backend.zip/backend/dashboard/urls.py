from django.urls import path

urlpatterns = [
    # Add your URL patterns here for dashboard app
]
